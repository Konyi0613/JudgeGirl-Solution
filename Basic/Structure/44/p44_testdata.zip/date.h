#ifndef DATE_H
#define DATE_H

struct Date {
    unsigned int year;
    unsigned int month;
    unsigned int day;
};

#endif
