for i in {1..10}
do
    ./a.out < $i.in > $i.out
done