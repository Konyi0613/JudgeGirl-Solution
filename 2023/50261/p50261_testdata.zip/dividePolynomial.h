void dividePolynomial(int f[], int g[]);
