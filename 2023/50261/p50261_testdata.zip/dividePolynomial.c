#include "dividePolynomial.h"

void dividePolynomial(int f[], int g[]) {
    int n = f[0], m = g[0];
    for (int i = 1; i<=n-m+1; i++) {
        int q = f[i] / g[1];
        f[i] = q;
        for (int j = 1; j<=m; j++)
            f[i + j] -= g[j + 1] * q;
    }
    f[0] = n-m;
    int cnt = -1;
    for (int i = n-m+2; i<=n+1; i++) {
        if (cnt == -1 && f[i] != 0)
            cnt = 0;
        if (cnt != -1)
            g[++cnt] = f[i];
    }
    if (cnt == -1) {
        g[0] = g[1] = 0;
    } else {
        g[0] = cnt - 1;
    }
}
