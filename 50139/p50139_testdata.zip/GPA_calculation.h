struct Class{
	int academic_credit;
	char score[3];
};
struct Student{
	char name[20];
	int N_class;
	int N_credit;
	double GPA;
	struct Class all_class[10];
};

void GPA_calculation(struct Student all_student[], int N);